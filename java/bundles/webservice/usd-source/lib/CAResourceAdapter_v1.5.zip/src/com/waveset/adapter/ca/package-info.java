@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ca.com/UnicenterServicePlus/ServiceDesk")
package com.waveset.adapter.ca;
