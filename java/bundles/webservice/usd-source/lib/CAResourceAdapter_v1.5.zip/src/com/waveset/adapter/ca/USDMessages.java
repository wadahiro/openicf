/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.waveset.adapter.ca;

/**
 *
 * @author developer
 */
public interface USDMessages {

    public static final String RESATTR_ENDPOINT = "RESATTR_CONN_URL";
    public static final String RESATTR_USER = "RESATTR_ADMIN_USER";
    public static final String RESATTR_PASSWORD = "RESATTR_ADMIN_PASSWORD";
    public static final String RESATTR_POLICY = "LG_POLICY";
    public static final String RESATTR_WSDL_URL = "RESATTR_WSDL_URL";
    public static final String RESATTR_ENDPOINT_HELP = "CAS_RESATTR_ENDPOINT_HELP";
    public static final String RESATTR_USER_HELP = "RESATTR_HELP_130";
    public static final String RESATTR_PASSWORD_HELP = "RESATTR_HELP_128";
    public static final String RESATTR_POLICY_HELP = "CAS_RESATTR_POLICY_HELP";
    public static final String RESATTR_WSDL_URL_HELP = "CAS_RESATTR_WSDL_URL_HELP";
    public static final String CAS_ERROR_START_CONNECTION = "CAS_ERROR_START_CONNECTION";
    public static final String CAS_ERROR_AUTHENTICATE_CONNECTION = "CAS_ERROR_AUTHENTICATE_CONNECTION";
    public static final String CAS_ERROR_REQUIRED_ATTR_MISSING = "CAS_ERROR_REQUIRED_ATTR_MISSING";
    public static final String CAS_ERROR_UNMARSHAL_ERROR = "CAS_ERROR_UNMARSHAL_ERROR";
    public static final String CAS_ERROR_UNMARSHAL_NULLINPUT = "CAS_ERROR_UNMARSHAL_NULLINPUT";
    public static final String CAS_ERROR_HANDLE_NOT_FOUND = "CAS_ERROR_HANDLE_NOT_FOUND";
    public static final String CAS_ERROR_INVALID_RESOURCEATTRIBUTE = "CAS_ERROR_INVALID_RESOURCEATTRIBUTE";
    public static final String CAS_ERROR_USER_NOT_EXIST = "CAS_ERROR_USER_NOT_EXIST";
    public static final String CAS_ERROR_ATTRIBUTE_RESOLVE = "CAS_ERROR_ATTRIBUTE_RESOLVE";
}
